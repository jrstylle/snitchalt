var pageBody = document.querySelector('body'); 
pageBody.removeAttribute('data-snitchalt');
var pageBody = document.querySelector('body'); 
pageBody.setAttribute('data-snitchalt', "enable");
<p align="center">
  <img src="https://raw.githubusercontent.com/jrstylle/Snitchalt/master/icons/icon128.png" alt="Snitchalt" width="128" />
</p>
<hr>

<h1>Snitchalt</h1>
<p>The Snitchalt is a Google Chrome extension that find images without the attribute alt</p>


<h2>Instalation</h2>
<ol>
  <li>Download the extension</li>
  <li>Now in Chrome, open the browser menu, go to "Tools" and click "Extensions";</li>
  <li>Enable the "Developer Mode" option and click "Load expanded extension ...";</li>
  <li> Finally, locate the directory on your computer where the extension was saved, unpack the files, select the directory with the same extension name and click "OK". The extension is installed.</li>
</ol>